module.exports = {
  keywords: require('./lib/keywords'),
  codepoints: require('./lib/font/codepoints'),
  svg: require('./build/svg.json')
}
